public class Machine {
    public static void main(String[] args) {
        double esp = 8;
        int milk = 7;
        int iCream = 3;
        int syrup = 4;
        int juice = 5;

        System.out.println((esp>=8)?"Можно налить стакан эспрессо":"Нельзя налить стакан эспрессо");
        System.out.println((milk>=8)?"Можно налить стакан молока":"Нельзя налить стакан молока");
        System.out.println((iCream>=8)? "Можно сделать стакан мороженного":"Нельзя сделать стакан мороженного");
        System.out.println((syrup>=8)?"Можно налить стакан сиропа":"Нельзя налить стакан сиропа");
        System.out.println((juice>=8)?"Можно налить стакан сока":"Нельзя налить стакан сока");

        System.out.println((esp>=8 * 0.4 && milk>=8 * 0.6)? "Недостаточно ингридиентов" : "Готовлю Флэт-Уйат");
        System.out.println((esp>=8*0.15 && milk>=8*0.85)?"Готовлю Латте":"Недостаточно ингридиентов");
        System.out.println((syrup>=8*0.1 && iCream>=8*0.5 && esp>=8*0.35)?"Готовлю смузи":"Недостаточно ингридиентов");
    }
}
