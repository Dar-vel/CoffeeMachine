public class Machine {
    public static void main(String[] args) {
        double esp = 8;
        int milk = 7;
        int iCream = 3;
        int syrup = 4;
        int juice = 5;

        if (esp>=8){System.out.println("Можно налить стакан эспрессо" );
        }else{
            System.out.println("Нельзя налить стакан эспрессо");}

        System.out.println((milk>=8)?"Можно налить стакан молока":"Нельзя налить стакан молока");
        System.out.println(iCream>=8? "Можно сделать стакан мороженного":"Нельзя сделать стакан мороженного");
        System.out.println((syrup>8)?"Можно налить стакан сиропа":"Нельзя налить стакан сиропа");
        System.out.println((juice>8)?"Можно налить стакан сока":"Нельзя налить стакан сока");

        if ((esp-(8*0.4))>0 && (milk-(8*0.6))>0) {
            System.out.println("Готовлю Флэт-Уйат");
        }else{
            System.out.println("Недостаточно ингридиентов");
        }

        if ((esp-(8*0.15))>0 && (milk-(8*0.85))>0) {
            System.out.println("Готовлю Латте");
        }else{
            System.out.println("Недостаточно ингридиентов");
        }

        System.out.println((syrup-(8*0.1)>=0 && (iCream-(8*0.5)>0) && (esp-(8*0.35)>0))?"Готовлю смузи":"Недостаточно ингридиентов");
    }
}
